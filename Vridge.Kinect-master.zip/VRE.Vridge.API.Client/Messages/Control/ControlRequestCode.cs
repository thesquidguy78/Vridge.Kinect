﻿namespace VRE.Vridge.API.Client.Messages.Control
{
    public enum ControlRequestCode
    {
        RequestEndpoint = 1,
        RequestStatus = 2,        
    }
}
