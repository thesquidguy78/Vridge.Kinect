﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using NetMQ;

namespace VRE.Vridge.API.Client.Helpers
{
    internal static class Logger
    {
        internal static void Debug(string msg)
        {

        }

        internal static void Error(string msg)
        {

        }
    }
}
